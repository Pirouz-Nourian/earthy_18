﻿"""Provides a scripting component.
    Inputs:
        x: The x script variable
        y: The y script variable
    Output:
        a: The a output variable"""

__author__ = "TOI"
__version__ = "2018.10.28"

import rhinoscriptsyntax as rs
import Rhino
import Rhino.Geometry as rg

underY = 100
topY = 100
leftX = 100
rightX = 100

for circle in Circles:
    center = circle.Center
    if center.Y > courtyard_size[1]:
        print 'panw {}'.format(center)
        topY = min(center.Y, topY)
    elif center.Y < 0:
        print 'katw {}'.format(center)
        underY = min(underY, abs(center.Y))
    elif center.X > courtyard_size[0]:
        print 'dexia {}'.format(center)
        rightX = min(rightX, center.X)
    else:
        print 'aristera {}'.format(center)
        leftX = min(leftX, abs(center.X))
"""
    if center.Y < 0:
        underY = min(underY, abs(center.Y))
    elif center.Y > 0 and center.X <= courtyard_size[0]:
        topY = min(topY, center.Y)
    elif center.X < 0:
        print center.X
        leftX = max(leftX, center.X)
    else:
        rightX = min(rightX, center.X)
"""
print 'oria {} {} {} {}'.format(underY, topY, leftX, rightX)
center = Circles[0].Center
aligned_circles = []

for circle in Circles:
    center = circle.Center
    if center.Y > courtyard_size[1]:
        translation = rg.Vector3d(0, topY - center.Y, 0)
        circle.Translate(translation)
    elif center.Y < 0:
        translation = rg.Vector3d(0, -underY - center.Y, 0)
        circle.Translate(translation)
    elif center.X > courtyard_size[0]:
        translation = rg.Vector3d(rightX - center.X, 0, 0)
        circle.Translate(translation)
    else:
        translation = rg.Vector3d(-leftX - center.X, 0, 0)
        circle.Translate(translation)


aligned_circles = Circles

print aligned_circles
