﻿"""Provides the inputs to the main script.
    Inputs:
        No_caravans: The number of caravans
        No_couples: The number of couples
        No_children: The number of children
    Output:
        output: A list of the spaces to render, along with render info"""

import rhinoscriptsyntax as rs
import math 

No_persons= 2*No_couples+No_children

# Formulas to calculate the room areas based on the inputs
areas = {
    "courtyard": No_caravans*25,
    "kitchen": 6 + 0.5*No_persons,
    "bathroom": 4 + 0.5*No_persons,
    "winter living room": 6 + 1*No_persons
}

# The heights of the rooms
heights = {
    'courtyard': 0,
    'kitchen': 3.5,
    'bathroom': 3,
    'entrance': 3.6,
    'winter living room': 3.5,
    'added bedroom': 3.5
}

# Function which determini the room dimension based on the inputs
def getDimensions(room):
    area = areas[room]
    length = math.floor(math.sqrt(area))
    depth = math.ceil(area/length)
    return [int(length), int(depth), heights[room]]

def getCourtyard():
    if No_caravans > 2 or No_caravans == 1:
        return getDimensions('courtyard')
    return [5, 5]

def getEntranceDimensions():
    if No_caravans > 2:
        return [2, 2, heights['entrance']]
    return [2, 2, heights['entrance']]

def getExtraRoomNumber():
    return max(0, int(No_couples + math.ceil(No_children/4.0) - No_caravans));


spaces = [
    {'name': 'courtyard','dimensions': getCourtyard(), 'color': '', 'number': 1},
    {'name': 'caravan','dimensions': [5, 3], 'color': (203, 187, 160), 'number': No_caravans},
    {'name': 'liwan','dimensions': [2, 3], 'color': '', 'number': No_caravans},
    {'name': 'entrance', 'dimensions': getEntranceDimensions(), 'color': (0, 0, 0), 'number': 1},
    {'name': 'kitchen', 'dimensions': getDimensions('kitchen'), 'color': (29, 113, 184), 'number': 1},
    {'name': 'bathroom', 'dimensions': getDimensions('bathroom'), 'color': (0, 159, 227), 'number': 1},
    {'name': 'winter living room', 'dimensions': getDimensions('winter living room'), 'color': (135, 135, 135), 'number': 1},
]

# Extra controls to conditionally add come spaces based on inputs
if (No_persons > 5):
    iwan_dimensions = [3, 3]
else:
    iwan_dimensions = [4, 4]

if No_caravans > 2:
    spaces.insert(3, {'name': 'iwan', 'dimensions': iwan_dimensions, 'color': (243, 146, 0), 'number': 1})

if getExtraRoomNumber() > 0:
    spaces.append({'name': 'added bedroom', 'dimensions': [3, 3], 'color': (0, 0, 0), 'number': getExtraRoomNumber()})

    # Block which controls the output of the script based on the Run boolean input
if Run:
    rs.DeleteObjects(rs.AllObjects())
    output = spaces
else:
    output = []