﻿"""Provides the positions of the rooms, along with additional geometry info.
    Input:
        spaces: A list of rooms to be positioned around the courtyard
    Outputs:
        RoomsPerSideIndexed:
            A list of room indexes per side, as they(indexes) came up during the execution
        CourtyardAndCaravans:
            A joined BREP of the courtyard and caravans to be used to later trim the room surfaces
        RoomCircles:
            A circle drawn around its positioned room, to be later used for relaxation script
        CourtyardSize:
            The dimensions of the courtyard
        """

"""
The logic for positioning the rooms is as follows:
    1) We define a grid starting from the southwest corner of the courtyard, and "looping" back at it
    2) We place the appropriate number of caravans in randomly selected corners
    3) We place a liwan adjacent to each caravan
    4) The script now starts by rendering the rooms provided in the input in order,
        scanning for availability on the grid_status in counter-clockwise direction, 
        starting from the southwest corner.
    5) After every room is positioned, the grid status is updated and geometry is generated based on
        input dimensions and translated accordingly around the courtyard.

If a room does not fit in the grid, its positioning is skipped and next in order room is positioned.

"""

__author__ = "anna"
__version__ = "2018.10.03"

import rhinoscriptsyntax as rs
import scriptcontext as sc
import Rhino
import Rhino.Geometry as rg
import random
import math
import itertools
from copy import copy
sc.doc = Rhino.RhinoDoc.ActiveDoc
# Initialize variables
roomIndexRendered = 0
CourtyardAndCaravans = []
plane = rs.WorldXYPlane()
RoomCircles = []
liwanIndexes = [[], [], [], []]  #per side
roomIndexes = [[], [], [], []]   #per side
grid_status = [] # main data structure showing information about if a grid index is occupied ba room or not
RoomsPerSideIndexed = []
# calculate courtyard parameters
courtyard = filter(lambda s: s['name'] == 'courtyard', spaces)[0]
width = courtyard['dimensions'][0]
length = courtyard['dimensions'][1]
CourtyardSize = [length, width]
courtyard_rectangle = rg.Box(plane, rg.Interval(0, length), rg.Interval(0, width), rg.Interval(0, 10))
CourtyardAndCaravans.append(courtyard_rectangle.ToBrep())
perimeter = 2 * (width + length)


# courtayrd corners along with info about their overflow
corners = [
    {'name': 'WS', 'index': 0, 'overflow': False},
    {'name': 'SE', 'index': length, 'overflow': False},
    {'name': 'EN', 'index': length+width, 'overflow': False},
    {'name': 'NW', 'index': 2*length+width, 'overflow': False},
]

corner_indexes = map(lambda c: c['index'], corners)

# coodinate information to translate the caravans to the correct position when rendered
HtoBottomX = -5.0
HtoBottomY = -3.0
VtoBottomX = -3.0
VtoBottomY = -5.0
toTopX = -5.0
toTopY = float(width)

caravans = filter(lambda s: s['name'] == 'caravan', spaces)[0]

# Initializes the grid_status
for i in range(perimeter + 1):
    grid_status.append({'index': i, 'spaces' : []})

# Determine indexed sides based on their size
south_side = range(0,length + 1)
east_side = range(length,length+width+1)
north_side = range(length+width, 2*length+width+1)
west_side = range(2*length+width,perimeter)
west_side.append(0)

sides = [south_side, east_side, north_side, west_side]

# Returns the previous corner index of the input
def get_prev_corner(index):
    difs = map(lambda c: index-c, corner_indexes)
    positives = filter(lambda d: d>0, difs)
    return index - min(positives)
    
# Similarly returns the next corner index of the input
def get_next_corner(index):
    difs = map(lambda c: c-index, corner_indexes)
    positives = filter(lambda d: d>0, difs)
    if len(positives) > 0:
        return index + min(positives)
    return 0;

# Next two functions are used to check whether a room is overflowing a corner
def add_side(point):
    point_in_sides = ''
    if point in south_side:
        point_in_sides += 'S'
    if point in east_side:
        point_in_sides += 'E'
    if point in north_side:
        point_in_sides += 'N'
    if point in west_side:
        point_in_sides += 'W'
    if point < 0:
        point_in_sides += 'W'
    return point_in_sides

def check_overflow(start, end):
    sides = ''
    if add_side(start) != add_side(end):
        sides = add_side(start) + add_side(end)
        map(lambda c: c if c['name'] != sides else c.update({'overflow': True}), corners)

# function to render a caravan on the south or north side
def horizontal_caravan(caravan, translation):
    length = caravan['dimensions'][0]
    depth = caravan['dimensions'][1]
    color = caravan['color']
    caravan_rectangle = rg.Box(plane, rg.Interval(0, length), rg.Interval(0, depth), rg.Interval(0, 2.8))
    caravan_rectangle_moved = caravan_rectangle.ToBrep()
    caravan_rectangle_moved.Transform(translation)
    caravan_box = rs.AddBox([rg.Point3d(0, 0, 0), rg.Point3d(5, 0, 0), rg.Point3d(5, 3, 0), rg.Point3d(0, 3, 0), rg.Point3d(0, 0, 2.8), rg.Point3d(5, 0, 2.8), rg.Point3d(5, 3, 2.8), rg.Point3d(0, 3, 2.8)])
    rs.TransformObject(caravan_box, translation)
    CourtyardAndCaravans.append(caravan_rectangle_moved)
    return rs.ObjectColor(rs.TransformObject(rs.AddPlaneSurface(plane, length, depth), translation), color)

# function to render a caravan on the east or west side
def vertical_caravan(caravan, translation):
    length = caravan['dimensions'][0]
    depth = caravan['dimensions'][1]
    color = caravan['color']
    caravan_rectangle = rg.Box(plane, rg.Interval(0, depth), rg.Interval(0, length), rg.Interval(0, 2.8))
    caravan_rectangle_moved = caravan_rectangle.ToBrep()
    caravan_rectangle_moved.Transform(translation)
    caravan_box = rs.AddBox([rg.Point3d(0, 0, 0), rg.Point3d(3, 0, 0), rg.Point3d(3, 5, 0), rg.Point3d(0, 5, 0), rg.Point3d(0, 0, 2.8), rg.Point3d(3, 0, 2.8), rg.Point3d(3, 5, 2.8), rg.Point3d(0, 5, 2.8)])
    rs.TransformObject(caravan_box, translation)
    CourtyardAndCaravans.append(caravan_rectangle_moved)
    return rs.ObjectColor(rs.TransformObject(rs.AddPlaneSurface(plane, depth, length), translation), color)

# function to be called when adding a caravan.
def add_caravan(end, caravan):
    start = end - caravan['dimensions'][0]
    if end in corner_indexes or end == perimeter:
        if end == perimeter/2:
            translation = rg.Transform.Translation(courtyard['dimensions'][1] , 0.0, 0.0)
            vertical_caravan(caravan, translation)
        elif end == perimeter:
            translation = rg.Transform.Translation(-caravan['dimensions'][1] , 0.0, 0.0)
            vertical_caravan(caravan, translation)
    elif (end in south_side):
        translation = rg.Transform.Translation(HtoBottomX + end, HtoBottomY, 0.0)
        horizontal_caravan(caravan, translation)
    elif (end in east_side):
        translation = rg.Transform.Translation(courtyard['dimensions'][1] , VtoBottomY + end - corner_indexes[1], 0.0)
        vertical_caravan(caravan, translation)
    elif (end in north_side):
        translation = rg.Transform.Translation(courtyard['dimensions'][1] - end + corner_indexes[2], toTopY, 0.0)
        horizontal_caravan(caravan, translation)
    elif (end in west_side):
        translation = rg.Transform.Translation(-3, width - end + corner_indexes[3], 0)
        vertical_caravan(caravan, translation)
    check_overflow(start, end)
    updated_start = get_prev_corner(end)
    for i in range(updated_start, end + 1):
        if i < 0:
            continue
        grid_status[i]['spaces'].append('caravan')

# Function that determines whether a corner is empty or not
def is_free_corner(index):
    corner = filter(lambda c: c['index'] == index, corners)
    if corner == []:
        return False
    return not corner[0]['overflow']

# Helper function that scans the grid and returns whether every index is occupied or not
def get_occupation_grid(grid):
    occupied = []
    for i,g in enumerate(grid):
        if i == 0:
            occupied.append(grid[0]['spaces'] == [])
        elif i == perimeter:
            occupied.append(grid[perimeter]['spaces'] == [])
        elif (grid[i+1]['spaces'] == [] or grid[i-1]['spaces'] == [] or grid[i]['spaces'] == []
        or (len(grid[i]['spaces']) == 1 and len(grid[i+1]['spaces']) == 1 and grid[i]['spaces'][0] != grid[i+1]['spaces'][0])
        or (len(grid[i]['spaces']) == 1 and len(grid[i-1]['spaces']) == 1 and grid[i]['spaces'][0] != grid[i-1]['spaces'][0])):
            occupied.append(True)
        else:
            occupied.append(False)
    return occupied

# Function which uses the info returned by get_occupation_grid and returns more information
# about space availability for every side
def check_availability(grid):
    occupation_grid = get_occupation_grid(grid)
    pos, max_len, cum_pos = 0, 0, 0
    sides = []
    sides.append(occupation_grid[slice(0,length)])
    sides.append(occupation_grid[slice(length,length + width)])
    sides.append(occupation_grid[slice(length + width,2*length + width)])
    sides.append(occupation_grid[slice(2*length + width,perimeter + 1)])
    space = []
    for side in sides:
        lengths=[]
        positions=[]
        for k, g in itertools.groupby(side):
            if k == True:
                pat = len(list(g))
                if cum_pos in corner_indexes:
                    lengths.append(pat)
                    positions.append(cum_pos)
                elif cum_pos + pat == perimeter:
                    lengths.append(pat)
                    positions.append(cum_pos)
                else:
                    lengths.append(pat)
                    positions.append(cum_pos)
                cum_pos += pat
            else:
                cum_pos += len(list(g))
        if lengths != []:
            if lengths[0] + positions[0] in corner_indexes:
                    lengths[0] += 1
        space.append({'max': lengths, 'from': positions})
    return space

# Function that gets the dimensions and start point of a room and returns info for its rendering such as
# its orientation and translation values.
def get_render_info(length, depth, start):
    if start in corner_indexes:
        corner = corner_indexes.index(start)
        if corner == 0:
            return {'orientation': 'horizontal', 'x_trans': 0, 'y_trans': -depth + 1,'side': 0}
        elif corner == 2:
            return {'orientation': 'horizontal', 'x_trans': courtyard['dimensions'][1] - length + 1, 'y_trans': courtyard['dimensions'][0], 'side': 2}
        elif corner == 1:
            return {'orientation': 'vertical', 'x_trans': courtyard['dimensions'][1], 'y_trans': 0,  'side': 1}
        else:
            return {'orientation': 'vertical', 'x_trans': -depth + 1, 'y_trans': courtyard['dimensions'][0] - length + 1, 'side': 3}
    if start in south_side:
        return {'orientation': 'horizontal', 'x_trans': start, 'y_trans': -depth + 1,  'side': 0}
    elif start in east_side:
        return {'orientation': 'vertical', 'x_trans': courtyard['dimensions'][1], 'y_trans': start- corner_indexes[1],  'side': 1}
    elif start in north_side:
        return {'orientation': 'horizontal', 'x_trans': courtyard['dimensions'][1] - start + corner_indexes[2] - length + 1, 'y_trans': courtyard['dimensions'][0],  'side': 2}
    else:
        return {'orientation': 'vertical', 'x_trans': -depth + 1, 'y_trans': courtyard['dimensions'][0] - start + corner_indexes[3] - length + 1, 'side': 3}

# Function that draws a circle around the area of a rectangle representation fo a room
def getCircle(rectangle):
    center = rectangle.Center
    radius = math.sqrt(pow(rectangle.Width, 2) + pow(rectangle.Height, 2))/2
    return rg.Circle(center, radius)

# Function that updates the per side indexes for every room
def updateSideIndexes(tag, side):
    global roomIndexRendered
    if tag == 'liwan':
        liwanIndexes[side].append(roomIndexRendered)
    else:
        roomIndexes[side].append(roomIndexRendered)
    roomIndexRendered += 1

# Functions that renders the room
def render_space(length, depth, start, color, tag):
    render_info = get_render_info(length, depth, start)
    updateSideIndexes(tag, render_info['side'])
    translation = rg.Transform.Translation(render_info['x_trans'], render_info['y_trans'], 0.0)
    if render_info['orientation'] == 'horizontal':
        rect = rs.TransformObject(rs.AddPlaneSurface(plane, length-1, depth-1), translation)
        if tag != 'caravan':
            toCircle = rg.Rectangle3d(plane, length - 1, depth - 1)
            center = toCircle.Center
            if render_info['y_trans'] > 0:
                circle_y_trans = width + 1 - center.Y
            else: 
                circle_y_trans = -1 - center.Y
            circleTrans = rg.Transform.Translation(render_info['x_trans'], circle_y_trans, 0.0)
            toCircle.Transform(translation)
            circle = getCircle(toCircle)
            RoomCircles.append(circle)
        rs.ObjectColor(rect, color)
    else:
        rect = rs.TransformObject(rs.AddPlaneSurface(plane, depth -1, length-1), translation)
        if tag != 'caravan':
            toCircle = rg.Rectangle3d(plane, depth - 1, length - 1)
            center = toCircle.Center
            if render_info['x_trans'] > 0:
                circle_x_trans = courtyard['dimensions'][1] + 1 - center.X
            else: 
                circle_x_trans = -1 - center.X
            circleTrans = rg.Transform.Translation(circle_x_trans, render_info['y_trans'], 0.0)
            toCircle.Transform(translation)
            circle = getCircle(toCircle)
            RoomCircles.append(circle)
        rs.ObjectColor(rect, color)

# function to upgrade the grid after positioning a room
def update_grid_status(start, end, tag):
    for i in range(start, end):
       if i > perimeter:
           break
       else:
           grid_status[i]['spaces'].append(tag)

# Main function for rendering a room
# It checks grid availability, decides on the start position,
# and renders room along with updating the grid.
def add_space(space):
    length = space['dimensions'][0] + 1
    depth = space['dimensions'][1] + 1
    tag = space['name']
    color = space['color']
    availables = check_availability(grid_status)
    for side in availables:
        if len(side['from']) == 0:
            continue
        if len(side['max']) > 0 and side['max'][0] + side['from'][0] - 1 == perimeter:
            next_corner_index = [0]
        else:
            next_corner_index = filter(lambda c: len(side['max']) > 0 and c == side['max'][0] + side['from'][0] - 1, corner_indexes)
        if len(side['max']) > 0 and side['max'][0] >= length:
            update_grid_status(side['from'][0], side['from'][0] + length, tag)
            render_space(length, depth, side['from'][0], color, tag)
            break
        elif (len(next_corner_index) > 0) and (is_free_corner(next_corner_index[0])):
            if next_corner_index[0] == 0:
                fill_until = perimeter + 1
            else:
                fill_until = next_corner_index[0] + 1
            for i in range(side['from'][0], fill_until):
                grid_status[i]['spaces'].append('occupied')
            render_space(length, depth, side['from'][0], color, tag)
            break

# Function that adds the liwan to the geometry
def add_liwan(start):
    render_info = get_render_info(2, 3, start)
    translation = rg.Transform.Translation(render_info['x_trans'], render_info['y_trans'], 0.0)
    rs.ObjectColor(rs.TransformObject(rs.AddPlaneSurface(plane, 2, 3), translation), (120, 80, 80))

# Function that renders the caravans
def render_caravans(No_caravans):
    add_liwans = True
    offset = 2
    caravan_corners = random.sample(corner_indexes, caravans['number'])
    if No_caravans == 2:
        offset = 5
        add_liwans = False
        caravan_corners = [corner_indexes[1], corner_indexes[3]]
    elif No_caravans == 3:
        caravan_corners = [corner_indexes[0], corner_indexes[1], corner_indexes[2]]
    for c in caravan_corners:
        add_caravan(c + offset, spaces[1])
        if add_liwans:
            liwan_start = c-2
            if liwan_start < 0 :
                liwan_start = perimeter - 2
            render_space(3,4,liwan_start,spaces[3]['color'], 'liwan')
            update_grid_status(liwan_start, liwan_start + 3, 'liwan')

# Ths spaces to be rendered after caravans and liwans are positioned
spaces_to_render = filter(lambda s: s['name'] not in ['caravan', 'courtyard', 'liwan'], spaces)

render_caravans(caravans['number'])
map(lambda space: add_space(space), spaces_to_render)

# Joins the liwan indexes and room indexes per side, putting the liwans at the end
for index, liwanIndex in enumerate(liwanIndexes):
    RoomsPerSideIndexed.append(roomIndexes[index] + liwanIndex)
