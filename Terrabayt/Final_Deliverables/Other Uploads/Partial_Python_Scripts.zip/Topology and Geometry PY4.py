﻿"""Provides a scripting component.
    Inputs:
        x: The x script variable
        y: The y script variable
    Output:
        a: The a output variable"""

__author__ = "TOI"
__version__ = "2018.10.28"

import rhinoscriptsyntax as rs
import Rhino
import Rhino.Geometry as rg
import math
NoRooms = 8
def chunks(l, n):
    # For item i in a range that is a length of l,
    for i in range(0, len(l), n):
        # Create an index range for l of n items:
        yield l[i:i+n]

roomBreps = list(chunks(RoomsSurfaces, int(len(RoomsSurfaces)/NoRooms)))



rooms = rg.Brep.JoinBreps(RoomsSurfaces, 0.01)
print len(rooms)
joinedRooms = []
for room in rooms:
    closed = room.CapPlanarHoles(0.01)
    joinedRooms.append(closed)

joinedRooms = rg.Brep.JoinBreps(joinedRooms, 0.01)
"""
for room in roomBreps:
    joined = rg.Brep.JoinBreps(room, 0.01)
    #closed = joined[0].CapPlanarHoles(0.01)
    joinedRooms.append(joined[0])


print joinedRooms
print RoomsPerSideIndexed

joinedRooms[2].Flip()
a = joinedRooms[4].Trim(joinedRooms[2], 0.01)
joinedRooms[2].Flip()
joinedRooms[4].Flip()
c = joinedRooms[2].Trim(joinedRooms[4], 0.01)
#c[0].Join(a[0], 0.01, True)

c = []
for side in [RoomsPerSideIndexed[0]]:
    if len(side) == 0:
        continue
    sideBrep = joinedRooms[side[0]]
    i=0
    while i < len(side)-1:
        if sideBrep.SolidOrientation == rg.BrepSolidOrientation.Inward:
            sideBrep.Flip()
        if joinedRooms[side[i+1]].SolidOrientation == rg.BrepSolidOrientation.Outward:
            joinedRooms[side[i+1]].Flip()
        temp1 = sideBrep.Trim(joinedRooms[side[i+1]], 0.01)
        print temp1
        if len(temp1) == 0:
            print 'rip'
            i +=1
            continue
        print 'yoo'
        a = temp1
        east_side = a
        sideBrep.Flip()
        joinedRooms[side[i+1]].Flip()
        b = joinedRooms[side[i+1]].Trim(sideBrep, 0.01)
        west_side = b
        print b
        sideBrep = rg.Brep.JoinBreps(a + b, 0.01)
        sideBrep = sideBrep[0]
        i += 1
    c.append(sideBrep)


north_side = []
south_side = []
north1 = joinedRooms[RoomsPerSideIndexed[2][0]]
north2 =  joinedRooms[RoomsPerSideIndexed[2][1]]
if north1.SolidOrientation == rg.BrepSolidOrientation.Inward:
    north1.Flip()
elif north2.SolidOrientation == rg.BrepSolidOrientation.Outward:
    north2.Flip()
south1 = joinedRooms[RoomsPerSideIndexed[0][0]]
south2 =  joinedRooms[RoomsPerSideIndexed[0][1]]
if south1.SolidOrientation == rg.BrepSolidOrientation.Inward:
    south1.Flip()
elif south2.SolidOrientation == rg.BrepSolidOrientation.Outward:
    south2.Flip()
north_side.append([north1, north2])
south_side.append([south1, south2])


west_side = joinedRooms

"""