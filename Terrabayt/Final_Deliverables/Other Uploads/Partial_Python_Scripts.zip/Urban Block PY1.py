﻿
indexes = []

print dir()
for count in range(99):
    if 'house{}'.format(count+1) in dir():
        indexes.append(len(eval('house{}'.format(count+1))))
    else:
        break

splits=indexes