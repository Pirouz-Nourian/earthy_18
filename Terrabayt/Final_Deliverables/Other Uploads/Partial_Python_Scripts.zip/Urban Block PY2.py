﻿import rhinoscriptsyntax as rs
import Rhino
import math

print curves.Branches[0]

points = []

for branch in curves.Branches:
    caravan_centers = []
    no_caravans = len(branch)
    for curve in branch:
        bb = curve.GetBoundingBox(True)
        caravan_centers.append(bb.Center)
    if no_caravans < 6:
        polyline = Rhino.Geometry.Polyline(caravan_centers)
        points.append(polyline.CenterPoint())

center = points

